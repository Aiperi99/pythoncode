#function adding numbers
def add_the_numbers(start, end, step):
    total = 0
    for i in range (start, end+step, step):
        print (i)
        total +=i
    print ("--------------")   
    return total
    
print (add_the_numbers(2,20,2))