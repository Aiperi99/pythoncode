name = input ('please enter your name: ' )
age = input ('please enter your age: ' )

print ('Hi  ' + name + '!')
print ('your age is ' + age + '. and its nice!') #not need to str(age) because of input

