import math 
import random
def prime (n):
    if n==1: return False
    is_prime =True
    for i in range (2, int(math.sqrt(n))+1):
        if n%i==0:
            is_prime=False
            break
    return is_prime
        
def random_numbers(a,b):
    num=a + int((b-a+1)*random.random())
    return num

for i in range (1.11):
    X = []  
    counter = 0
    
    for j in range (1000):
        a=100*i
        b=100*i+100
        num = random_numbers(a,b)
        X.append(num)
    for num in X:
        if prime(num)==True:
            counter+=1
print (a, b, len(X), counter, counter/len(X))
