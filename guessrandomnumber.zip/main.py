import random 
x = int (100*random.random() + 1)

count = 0

found = False
while (found == False):
    guess = int(input("Enter the number: "))
    count += 1
    if(x > guess):
        print ("Your number is too small!")
    elif (x < guess):
        print ("Your number is too big!")
    elif (x == guess):
        found = True
        print ("You got it! The number is: ", guess)
        
print ("You needed ", count, "guesses.")