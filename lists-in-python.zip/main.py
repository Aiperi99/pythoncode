#pisat bukvy
lan1 = "Python"
lan2 = 'JavaScript'
lan3 = "Java"
langs = [] #empty list

langs.append(lan1)
langs.append(lan2)
langs.append(lan3)

for i in range (len(langs)):
    print(langs[i])
    
    
#-----------    
for element in langs:
    print (element)
    
#print (lan2[0:1] + lan2[4:5])

