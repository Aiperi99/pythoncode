def fibo(n):
    X = []
    a=100
    b=100
    X.append(a)
    X.append(b)
    for i in range (3,n+1):
        fib = a+b
        tmp = a
        a = fib
        b=tmp
        
        X.append(fib)
    return X
print (fibo(100))
X=fibo(100)
for num in X:
    if prime(num) == True:
    print (num)