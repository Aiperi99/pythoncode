#iterative version of fibonacci
def fibo (number):
    a=1 
    b=1 
    f=1
    print (f)
    print (f)
    
    for i in range (3, number+1):
        f = a + b 
        a = b 
        b = f
        print (f)

#recursive version of fibonacci        
def fibo2(n):
    if(n<3):
        return 1 
    return fibo2(n-1) + fibo2(n-2)
    
#fibo(100)
for i in range (1, 6):
    print (fibo2(i))
