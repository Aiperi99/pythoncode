#iterative version of fibonacci
def fibo (number):
    a=1 
    b=1 
    f=1
    print (f)
    print (f)
    
    for i in range (3, number+1):
        f = a + b 
        a = b 
        b = f
        print (f)
        
fibo(5)