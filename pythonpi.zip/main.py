X=[]
N = 1000000
for i in range (1,N+1):
    n=2*i-1
    X.append(n)
    
pi = 0
d = len(X)

for i in range (d):
    pi = pi  + ((-1)**i)/X[i]
pi = pi*4
print (pi)
