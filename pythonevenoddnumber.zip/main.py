num = int(input("Please enter integer number: "))
if num % 2 ==0:
    print (str (num) + ' is even')
else: 
    print (str(num) + ' is odd')

